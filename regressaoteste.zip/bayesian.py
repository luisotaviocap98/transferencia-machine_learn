from sklearn.linear_model import BayesianRidge
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

br = BayesianRidge()

space = dict()
space['tol'] = [ 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0]
space['alpha_1'] = [ 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
space['alpha_2'] = [ 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
space['lambda_1'] = [ 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
space['lambda_2'] = [ 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
space['fit_intercept'] = [True, False]
space['normalize'] = [True, False]


hp.compute('BayesianRidge', br, space, parametros.cv, parametros.X, parametros.y)