from skopt import BayesSearchCV

class Hyperparameter:
    def __init__(self):
        pass
    
    def compute(self,nome, model, space, cv, X, y):
        self.search = BayesSearchCV(estimator = model,search_spaces = space, scoring = 'accuracy', 
                              cv = cv, n_iter = 50, random_state=1, verbose=15)
        self.search.fit(X,y)
        
        with open('{}.txt'.format(nome),'w') as data: 
            data.write('Melhores parametros: ')
            data.write(str(self.search.best_params_))
            data.write('\n')
            data.write('Desempenho do melhor modelo: ')
            data.write(round(self.search.best_score_,4))