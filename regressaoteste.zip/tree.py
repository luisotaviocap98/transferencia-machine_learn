from sklearn.tree import DecisionTreeRegressor
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

dtc = DecisionTreeRegressor()

space = dict()
space['criterion'] = ['squared_error', 'friedman_mse', 'absolute_error', 'poisson']
space['splitter'] = ['best', 'random']  
space['max_features'] = ['auto', 'sqrt', 'log2']
space['min_samples_leaf'] = [1,2,3]
space['max_depth'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50, 100]
space['max_leaf_nodes'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50, 100]
space['ccp_alpha'] = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0]

hp.compute('ArvoreR', dtc, space, parametros.cv, parametros.X, parametros.y)