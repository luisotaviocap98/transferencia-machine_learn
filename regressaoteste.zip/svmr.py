from sklearn.svm import SVR
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

svm = SVR()

space = dict()
space['kernel'] = ['linear', 'poly', 'rbf', 'sigmoid']
space['gamma'] = ['scale', 'auto']  
space['cache_size'] = [100,200,300]
space['tol'] = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1, 10]
space['shrinking'] = [True, False]
space['C'] = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0]
space['epsilon'] = [1e-3, 1e-2, 1e-1, 0.0, 0.1, 0.2, 0.3]

hp.compute('SVMR', svm, space, parametros.cv, parametros.X, parametros.y)