from sklearn.linear_model import LinearRegression
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

regressor = LinearRegression(n_jobs=-1)

space = dict()
space['fit_intercept'] = [True, False]
space['normalize'] = [True, False]
space['positive'] = [True, False]

hp.compute('LinearRegression', regressor, space, parametros.cv, parametros.X, parametros.y)