from sklearn.linear_model import Ridge
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

rd = Ridge()

space = dict()
space['alpha'] = [1e-3, 1e-2, 1e-1, 1.0, 2.0, 3.0]
space['fit_intercept'] = [True, False]
space['normalize'] = [True, False]
space['tol'] = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0]


hp.compute('Ridge', rd, space, parametros.cv, parametros.X, parametros.y)