import pandas as pd
from sklearn.model_selection import KFold
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.model_selection import train_test_split


class Config:
    def __init__(self):
        self.get_values()
        
    def get_values(self):
        self.df = pd.read_csv('./enade_classifier.csv',sep=',',decimal='.')
        features = self.df.loc[:, self.df.columns != 'nt_geral_categoria']
        self.y = self.df['nt_geral_categoria']
        self.X = SelectKBest(k=81, score_func=chi2).fit_transform(features, self.y)
        self.cv = KFold(n_splits=10, random_state=1, shuffle=True)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(self.X, self.y, test_size = 0.25)
        
    
    
# retornar treinos e testes, CV, 