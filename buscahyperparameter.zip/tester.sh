#!/bin/bash

{
    {python3 logistica.py || echo "Erro logistica"} &&
    {python3 knn.py || echo "Erro knn"} &&
    {python3 forest.py || echo "Erro forest"} &&
    {python3 arvore.py || echo "Erro arvore"} &&
    {python3 bayes.py || echo "Erro bayes"} &&
    {python3 svm.py || echo "Erro svm"} 
}
||
{
    echo "Ocorreu um erro"
}