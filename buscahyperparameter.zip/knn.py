from sklearn.neighbors import KNeighborsClassifier

from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

knn = KNeighborsClassifier(n_jobs=-1)

space = dict()
space['weights'] = ['uniform', 'distance']
space['n_neighbors'] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
space['algorithm'] = ['auto', 'ball_tree', 'kd_tree', 'brute']
space['p'] = [1,2,3]
space['leaf_size'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50]

hp.compute('KNN', knn, space, parametros.cv, parametros.X, parametros.y)