from sklearn.ensemble import RandomForestClassifier

from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

rf = RandomForestClassifier(n_jobs=-1)

space = dict()
space['criterion'] = ['gini', 'entropy']
space['class_weight'] = ['balanced', 'balanced_subsample']
space['n_estimators'] = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 150, 200]
space['max_features'] = ['auto', 'sqrt', 'log2']
space['min_samples_leaf'] = [1,2,3]
space['bootstrap'] = [True,False]
space['warm_start'] = [True,False]
space['max_depth'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50, 100]
space['max_leaf_nodes'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50, 100]


hp.compute('RandomForest', rf, space, parametros.cv, parametros.X, parametros.y)