from sklearn.naive_bayes import GaussianNB
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

gnb = GaussianNB()

space = dict()
space['var_smoothing'] = [1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0]

hp.compute('NaivesBayes', gnb, space, parametros.cv, parametros.X, parametros.y)