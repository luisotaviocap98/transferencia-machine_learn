from sklearn.linear_model import LogisticRegression

from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

clr = LogisticRegression(max_iter=500, n_jobs=-1)

space = dict()
space['solver'] = ['newton-cg', 'sag', 'saga', 'lbfgs']
space['tol'] = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1, 10]
space['multi_class'] = ['auto', 'ovr', 'multinomial']
space['warm_start'] = [True, False]
space['C'] = [1.0, 2.0, 3.0, 4.0, 5.0, 10.0]

hp.compute('RegressaoLogistica', clr, space, parametros.cv, parametros.X, parametros.y)