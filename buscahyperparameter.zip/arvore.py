from sklearn.tree import DecisionTreeClassifier
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

dtc = DecisionTreeClassifier()

space = dict()
space['criterion'] = ['gini', 'entropy']
space['splitter'] = ['best', 'random']  
space['max_features'] = ['auto', 'sqrt', 'log2']
space['min_samples_leaf'] = [1,2,3]
space['max_depth'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50, 100]
space['max_leaf_nodes'] = [1, 2, 3, 4, 5, 10, 15, 20, 30, 50, 100]
space['ccp_alpha'] = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0]

hp.compute('Arvore', dtc, space, parametros.cv, parametros.X, parametros.y)