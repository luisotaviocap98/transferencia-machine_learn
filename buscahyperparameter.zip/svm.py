from sklearn.svm import SVC
from preparation import Config
from hyper import Hyperparameter

parametros = Config()
hp = Hyperparameter()

svm = SVC()

space = dict()
space['kernel'] = ['linear', 'poly', 'rbf', 'sigmoid', 'precomputed']
space['gamma'] = ['scale', 'auto']  
space['decision_function_shape'] = ['ovo', 'ovr']
space['cache_size'] = [100,200,300]
space['tol'] = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1, 10]
space['probability'] = [True, False]
space['shrinking'] = [True, False]
space['C'] = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0]

hp.compute('SVM', svm, space, parametros.cv, parametros.X, parametros.y)